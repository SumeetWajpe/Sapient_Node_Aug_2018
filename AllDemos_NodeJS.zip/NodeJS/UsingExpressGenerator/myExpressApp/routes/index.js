var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/products', function(req, res, next) {
  res.render('productlist', { productList:[
    {name:'TV',price:20000},
    {name:'Mobile',price:10000},
    {name:'Laptop',price:40000}
  ] });
});

router.get('/employees', function(req, res, next) {
  //res.render('employeelist',  });

  // Connect to DB
  // Fire the query | fetch the records from collection in the database
  // Render the result by passing the model to the view


  // Get The connection string
  var url = "mongodb://localhost:27017/employees";
var MongoClient = mongodb.MongoClient;

MongoClient.connect(url,(err,db)=>{
    var collection = db.collection("employees");
    // Find all records !
    collection.find({}).toArray(function(err,result){
        if(err){
          console.log(err);
        }else if(result.length){
            // res.json(result);
            res.render('employeelist', {
              employeeList:result
             });
        }
        else{
            res.send("No Employees found !")
        }
    })
})

});

module.exports = router;
