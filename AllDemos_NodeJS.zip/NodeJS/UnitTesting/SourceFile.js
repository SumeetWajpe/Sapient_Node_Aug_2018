module.exports.Addition =  function (x,y){
    return x + y;
  }
