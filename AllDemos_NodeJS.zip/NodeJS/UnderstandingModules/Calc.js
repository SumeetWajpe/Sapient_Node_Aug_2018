// var MathModule = require('./Math');
var AddFunc = require('./Math').Addition;
console.log(AddFunc(20,30));