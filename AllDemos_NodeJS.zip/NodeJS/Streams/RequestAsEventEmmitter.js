var request = require('request');
var fs = require('fs');

var evtEmtr = request('http://www.google.com');

var response ="";

evtEmtr.on('data',function(chunkOfData){
        response += chunkOfData + ">>>>>>>>>> DATA >>>>>>>>>>";       
    console.log(response);
});
evtEmtr.on('error',function(chunkOfData){
    response += chunkOfData + ">>>>>>>>>> DATA >>>>>>>>>>";       
console.log(response);
});
evtEmtr.on('end',function(){
    console.log("\n\n The Request ended !! \n\n");
    // console.log(response);
    fs.writeFile('MyGoogleResponse.html',response)
});