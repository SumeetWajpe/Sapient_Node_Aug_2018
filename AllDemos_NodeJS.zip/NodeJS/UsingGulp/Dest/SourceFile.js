var x = 100;
var boolVar = false;

/*  This is a comment that will not be apart of minification */

function Addition(aVeryLongXVar,aVeryLongYVar){
        return aVeryLongXVar + aVeryLongYVar;
}