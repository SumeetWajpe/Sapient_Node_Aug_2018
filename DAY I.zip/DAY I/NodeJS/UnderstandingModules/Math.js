function  Add(x,y) {
        return x + y;
}

function  Product(x,y) {
    return x * y;
}

const PI = 3.14;

// module.exports.Addition = Add;
// module.exports.Multiplication = Product;
// module.exports.PIE = PI;

// Node uses CommonJS as module loader
module.exports = {
    Addition:Add,
    Multiplication:Product,
    PI:PI
}