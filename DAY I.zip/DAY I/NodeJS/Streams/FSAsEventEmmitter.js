var fs = require('fs');


var readableStream = fs.createReadStream("Input.txt");
var writeableStream = fs.createWriteStream("Output.txt");

readableStream.setEncoding("UTF8");
var allData = "";

// readableStream.on('data',function(chunk){
//         allData += chunk;
// });

// readableStream.on('end',function(){
//     writeableStream.write(allData);
//     writeableStream.end();
// });

readableStream.pipe(writeableStream);