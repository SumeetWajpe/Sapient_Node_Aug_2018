// Websocket server !

var http = require('http');
var fs = require('fs');
var socket = require('socket.io');

var hostname = "127.0.0.1";
var port = 4000;
var server = http.createServer((req,res)=>{
     fs.readFile('ClientPeer.html',function(err,dataFromTheFile){
        
        if(!err){
            res.writeHead(200,{"Content-Type":"text/html"})
            res.end(dataFromTheFile);
        }  
    })  
});
var io = socket.listen(server);
io.sockets.on('connection',(skt)=>{
    console.log('Connected !')
        setInterval(()=>{
            var dataFromServer = new Date();
                skt.emit('messageForClientPeer', dataFromServer);
        },2000);
        skt.on('messageFromClientPeer',(dataFromClient)=>{
            console.log('Data From CLient Peer : ' + dataFromClient)
        });
});
server.listen(port, hostname,()=>{
    console.log(`Server running at  ${hostname}:${port}`)
});