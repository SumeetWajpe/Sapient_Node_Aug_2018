var express = require('express');

var app = express();

class Product{
    constructor(){
        this.name= "Mobile";
        this.price = 30000;
    }
}

app.get('/',(req,res)=>{

    var products = [
        {name:'Mobile',price:20000},
        {name:'LED TV',price:30000},
        {name:'Laptop',price:50000}
    ];

        // res.send("<h1> Hello Express ! </h1>");
        // res.sendFile('Index.html',{root:__dirname });
       // res.set("Content-type","text/plain");
        res.send(new Product());
        //    res.json(products);
});

app.listen(3000,()=>{
    console.log('Server running @ 3000');
});