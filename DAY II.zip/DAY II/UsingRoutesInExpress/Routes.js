var express = require('express');
var app = express();
var bodyParser = require('body-parser');

var router = express.Router();
router.route('/products/:name/:size').get((req,res)=>{        
    var products = [
        {name:'Mobile',price:20000},
        {name:'LED TV',price:30000},
        {name:'Laptop',price:50000}
    ];    

        var n = req.params.name;// read the parameters
        var s = req.params.size;// read the parameters
        
        if(n){
            console.log(n);
            console.log(s);
            res.send(products[1])
        }else{
                 res.json(products);
        }
});

app.use(bodyParser.urlencoded({
    extended:true
}));

app.use('/data',router);

app.get('/',(req,res)=>{
    res.sendFile('Index.html',{root:__dirname });
});

app.post('/login',(req,res)=>{
        // read the username & password
        console.log('Posted from Client !');
       var name =  req.body.username;
       var pwd = req.body.password;
       console.log(name,pwd);
        res.send("success");
});
app.use((req,res)=>{
        res.statusCode = 404;
        res.send("Page Not Found !");
});
app.listen(3000,()=>{
    console.log('Server running @ 3000');
});